//: Playground - noun: a place where people can play

import UIKit

var factorial = 1;

//5! 구하기
for i in 1...5 {
    factorial = factorial*i
}
print(factorial)

(1...5).reduce(1) { (ret, item) -> Int in
    return ret*item
}

//multiply start number to end number
var i:Int
var start:Int = 3
var end:Int = 11

for i in start...end {
    for j in start...end{
        print("\(i)*\(j)=\(i*j)")
    }
}

(3...11).reversed().reduce(1){(ret,item) -> Int in
    return (3...11).reversed().reduce(1){ret2,item2) -> Int in
        return 
    }
}


//별 찍기
for i in 0...4 {
    var star: String = ""
    for j in 0...i {
        star += "*"
    }
    print(star)
}

(0...4).reduce(1) { (ret:Result, item: Int) -> String in
    var star:String = ""
    return star }

//matrix 덧셈
var emptyArray1: [[Int]] = [[Int]](repeating: [Int](repeating: 0, count: 3), count: 3)
var emptyArray2: [[Int]] = [[Int]](repeating: [Int](repeating: 0, count: 3), count: 3)
var resultArray3: [[Int]] = [[Int]](repeating: [Int](repeating: 0, count: 3), count: 3)

emptyArray1=[[4,2,1],[2,3,3],[4,2,1]]
emptyArray2=[[1,2,4],[1,2,2],[4,2,3]]

for i in 0...2 {
    for j in 0...2 {
        resultArray3[i][j] = emptyArray1[i][j] + emptyArray2[i][j]
    }
}
print(resultArray3)

//matrix 출력

for i in 0...2 {
    var matrix = ""
    for j in 0...2 {
        matrix += String(resultArray3[i][j]) + " "
    }
    print(matrix)
}



